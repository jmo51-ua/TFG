export default {
    methods: {
        logout() {
            this.$root.logged = false;
        }
    }
}